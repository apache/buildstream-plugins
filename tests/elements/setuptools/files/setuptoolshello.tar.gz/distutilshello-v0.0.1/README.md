# distutils Hello

A simple distutils hello world project
