# Meson Hello

A simple meson hello world project
